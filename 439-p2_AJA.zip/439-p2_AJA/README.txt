CSPC 439 Project 2 Cellular Automaton Rule 150 with Turing Machine
AJA Group: Andrew Pham - Juan Sanchez- Alexandria Wolfram

This program displays Wolfram's Cellular Automaton Rule 150 using a Turing Machine to model it on a 41x20 grid.

Contents:
TMCellularRule150.html
README.txt
assets folder: draw-stuff.js and styles.css
439 P2 Big O Essay

Requirements: 
Web browser that supports Javascript.

Instructions: 
Click on the TMCellularRule150.html file and open it on the compatible browser of your choice.

Sample invocation:
Click on the AutoRun button(only once) and the TM animations will start and the drawing will begin, click the pause button to stop at any time.
Click on the Step button and the procedure will run one TM reading and possible draw.

Features:
41x20 canvas matrix display
TM cell animation and drawing
TM canvas display and separate state display
AutoRun, Step, Pause buttons

Bugs:
Turing machine animation lags.